use databassignment;
Create table EMP2 ( EMPNO numeric(4) not null, ENAME varchar(30) not null, JOB varchar(10), MGR numeric(4), HIREDATE date, SAL numeric(7,2), DEPTNO numeric(2) ); 
Insert into EMP2 (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1000,  'Manish' , 'SALESMAN', 1003,  '2020-02-18', 600,  30) ;
Insert into EMP2 (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1001,  'Manoj' , 'SALESMAN', 1003,  '2018-02-18', 600,  30) ;
Insert into EMP2 (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1002 , 'Ashish', 'SALESMAN',1003 , '2013-02-18',  750,  30 );
Insert into EMP2 (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1004,  'Rekha', 'ANALYST', 1006 , '2001-02-18', 3000,  10);
Insert into EMP2 (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1005 , 'Sachin', 'ANALYST', 1006 ,  '2019-02-18', 3000, 10 );
Insert into EMP2 (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1006,  'Pooja',  'MANAGER'  ,     null    , '2000-02-18' ,6000, 10 );
select * from EMP2;
Create table dept (dno numeric(4) not null, dname varchar(10) not null,area varchar(30));
Insert into dept(dno,dname,area) values(10,'Store','Mumbai');
Insert into dept(dno,dname,area) values(20,'Purchase','Mumbai');
Insert into dept(dno,dname,area) values(30,'Store', 'Delhi');
Insert into dept(dno,dname,area) values(40,'Marketing','Pune');
Insert into dept(dno,dname,area) values(50,'Finance','Delhi');
select * from dept;

delimiter $$
create procedure q(IN x int,IN y int)
begin
select x + y;
select x - y;
select x * y;
select x / y;
end $$
call q(10,20);
drop procedure q;
-----------------------------q2
delimiter ##
create procedure q2(INOUT STR VARCHAR(30))
BEGIN
SET STR=(SELECT(STR));
END ##
SET @STR='pOOJA';
CALL q2(@STR);
SELECT @STR ;
DROP PROCEDURE Q2;

--------------------------Q3
DELIMITER $$
CREATE PROCEDURE Q3()
BEGIN
SELECT EMPNO ,ENAME , SAL FROM EMP2 ORDER BY SAL LIMIT 5;
END $$
CALL Q3;
------------------------------------------Q4
   DELIMITER $$
   CREATE PROCEDURE Q41()
   BEGIN
   CREATE TABLE EMP_LIST (EMP_ID int,E_ENAME VARCHAR(20),E_JOINING_DATE DATE);
   select * FROM EMP_LIST;
   END $$
   
   call Q41
  ------------ DROP PROCEDURE Q4;
   
   
   
   
   
   
    
   -------------------------------------Q5
   delimiter $$
create procedure Q5(in detno int,in detname varchar(200), in  detarea varchar(20))
begin
insert into dept(dno,dname,area) values(detno,detname,detarea);
end; $$
call Q5(60,'education','pune');
select * from dept;
-----------------------------------------------Q6
DELIMITER $$
CREATE PROCEDURE Q6(INOUT NUM INT ,OUT SQR INT ,OUT CUB1 INT)
BEGIN
DECLARE NUM1 INT;
SET NUM1=NUM ;
END $$
SET @NUM=2;
CALL Q6(@NUM ,@SQR ,@ CUBE1 );
SELECT @NUM ,@SQR,@ CUBE1;
------------------------------------------------Q6
/*delimiter $$
create procedure Que06( in value int ,out squr int,out cube int)
begin 
declare val1 int ;
set val1=value;
set squr = power(val1,2);
set cube = power(val1,3);
end;$$

call Que06(2,@sqr,@cube);
select @sqr;
select @cube;*/
----------------------------------------------Q7
delimiter $$
CREATE PROCEDURE SP_7(OUT ANS INT)
---------------------------------------------Q8
 delimiter $$
CREATE PROCEDURE SP_8(IN X INT,OUT STR VARCHAR(50))
BEGIN
SELECT concat(E.ENAME,' IS FROM ',D.DNAME) INTO STR  FROM EMP E INNER JOIN DEPT D ON D.DNO=E.DEPTNO WHERE E.DEPTNO=X AND E.EMPNO=1004;
END $$

CALL SP_8(10,@STR);
SELECT @STR;


BEGIN
DECLARE NUM int;
SET NUM=2;
SELECT NUM  INTO ANS ;
END $$

CALL SP_7(@ANS);
SELECT @ANS;
---------------------------------------------Q8

 delimiter $$
CREATE PROCEDURE Q8(IN X INT,OUT STR VARCHAR(50))
BEGIN
SELECT concat(ENAME,' IS FROM ',DNAME) INTO STR  FROM EMP2  INNER JOIN DEPT D ON D.DNO=E.DEPTNO WHERE E.DEPTNO=X AND E.EMPNO=1004;
END $$

CALL Q8(10,@STR);
SELECT @STR;
DROP Q8


delimiter $$
create procedure my2()
begin
declare x int default 0;
test:loop
if(x=10)then
iterate test;
end if ;
set x=x+1;
select x;
end loop;
end $$
call my1();












