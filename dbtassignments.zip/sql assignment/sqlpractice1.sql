create database sql1;
use sql1;
create table emp_details(emp_id int,full_name varchar(30),manager_id int,dateofjoining date,city varchar(30));
insert into emp_details(emp_id,full_name,manager_id,dateofjoining,city)
values(121,'John Snow',321,'2014/12/10','Toronto');
insert into emp_details(emp_id,full_name,manager_id,dateofjoining,city)
values(122,'Walter White',986,'2015/01/30','California');
insert into emp_details(emp_id,full_name,manager_id,dateofjoining,city)
values(421,'Kuldeep Rana',876,'2016/11/27','New Delhi');

select * from emp_details;
create table emp_salary(empid int,project varchar(30),salary int,variable int);
insert into emp_salary (empid,project,salary,variable)values(121,'P1',8000,500);
insert into emp_salary (empid,project,salary,variable)values(122,'P',10000,1000);
insert into emp_salary (empid,project,salary,variable)values(421,'P1',1200,0);
select * from emp_salary;
select * from emp_details where manager_id=986;
select project from emp_salary;
select * from emp_salary;
select date_format(dateofjoining,'%d-%b-%y')from emp_details;
select count(*) as total_count from emp_salary where project =p1;

